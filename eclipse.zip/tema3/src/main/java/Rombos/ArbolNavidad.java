package Rombos;

import java.util.Scanner;

public class ArbolNavidad {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int altura;

        System.out.println("Introduce la altura del árbol: ");
        altura = sc.nextInt();

        // Árbol de Navidad
        for (int i = 1; i <= altura; i++) {
            // Espacios en blanco
            for (int j = altura - i; j > 0; j--) {
                System.out.print(" ");
            }
            // Asteriscos y adornos
            for (int j = 0; j < 2 * i - 1; j++) {
                if (j % 3 == 0) {
                    System.out.print("o");
                } else if (j % 3 == 1) {
                    System.out.print("+");
                } else {
                    System.out.print("*");
                }
            }
            System.out.println();
        }

        // Tronco
        for (int i = 0; i < altura / 3; i++) {
            for (int j = 0; j < altura - 1; j++) {
                System.out.print(" ");
            }
            System.out.println("|");
        }
        sc.close();
    }
}